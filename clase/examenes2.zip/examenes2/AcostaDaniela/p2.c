#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b1=0,b2=0,c=0;
    int x=0;

    printf("Ingrese dos numeros\n");
    scanf("%d",&b1);
    scanf("%d",&b2);
    c=b1+b2;
    printf("%d\n",c);

    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    if(b2!=c)
    {
        b1=b2;
        b2=c;
        c=b1+b2;
        printf("%d\n",c);
    }
    return 0;
}

