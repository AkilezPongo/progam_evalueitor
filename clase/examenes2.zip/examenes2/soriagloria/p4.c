#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int=0;
    srand(time(NULL));
    data=rand()%100;
    for(i=0;i<=50;i++)
    {

    }

}
